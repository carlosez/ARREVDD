grant ALL on bolinf.XXSV_AR_REV_UTL to APPS;
grant select on bolinf.XXSV_GL_JE_AR_TRX_CUST_REPORT to APPS;
grant select on bolinf.XXSV_GL_JE_AR_TRX_CUST_REPORT to SV_DWUSER;
grant select on bolinf.XXSV_GL_JE_AR_TRX_CUST_REPORT to SV_MWUSER;
/
exit
/