create or replace public synonym XXSV_GL_JE_AR_TRX_CUST_REPORT for bolinf.XXSV_GL_JE_AR_TRX_CUST_REPORT;
create or replace public synonym XXSV_GL_JE_AR_TRX_CUST_REPORT for bolinf.XX_UTILITIES;
/
exit
/