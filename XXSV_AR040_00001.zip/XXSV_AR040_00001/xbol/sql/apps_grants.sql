grant select on GL_JE_SOURCES to bolinf with grant option;
/
exit
/